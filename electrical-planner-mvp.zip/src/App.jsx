import React from 'react';
import ElectricalPlannerMVP from './ElectricalPlannerMVP.jsx';

const App = () => {
  return <ElectricalPlannerMVP />;
};

export default App;
